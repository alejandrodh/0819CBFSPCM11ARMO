<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Home</h1>
    <h2>Lista de productos</h2>

    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <article>
        <img src="/storage/product/<?php echo e($product->featured_img); ?>" alt="">
        <h4 class="name"><?php echo e($product->name); ?></h4>
        <p class="description"><?php echo e($product->description); ?></p>
        <p class="price">Precio: <?php echo e($product->price); ?>$</p>
        <form class="" action="/addtocart" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
          <button type="submit" class="btn btn-success">Agregar al carrito</a>
        </form>


      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p>No hay productos disponibles</p>
    <?php endif; ?>



</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/2019/tm11b/mercadoliebre/resources/views/home.blade.php ENDPATH**/ ?>