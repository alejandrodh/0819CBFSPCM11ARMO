<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Mi Carrito</h1>
    <h2>Lista de productos</h2>

    <?php dd($items); ?>



</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/2019/tm11b/mercadoliebre/resources/views/cart.blade.php ENDPATH**/ ?>